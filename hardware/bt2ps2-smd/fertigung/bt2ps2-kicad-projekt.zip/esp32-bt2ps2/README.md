# ESP32 Bluetooth → PS/2 Tastatur-Adapter

Platine für [Hamberthm/esp32-bt2ps2](https://github.com/Hamberthm/esp32-bt2ps2): eine Bluetooth- oder BLE-Tastatur an einem alten PC mit PS/2- oder DIN-Tastaturanschluss.

**Stand 2026-09-19: Schaltplan fertig (ERC ohne Befund). Platine verlegt (Vorschlag), DRC ohne Befund, keine offene Verbindung.**

## Platine

**Leiterbahnen:** Das ist ein Vorschlag von einem einfachen Raster-Router (A*). Versorgung 0,5 mm, Signale 0,25 mm, 33 Vias für Signale und Versorgung. Dazu kommen Masse-Vias: 7 an den SMD-Massepads, 52 als Heftung zwischen den Flächen, 9 gegen Flächeninseln. Die Wege sind nicht schön, aber regelkonform. Nachbessern in KiCad lohnt sich vor allem bei langen Umwegen.

60 × 34 mm, 2 Lagen, GND-Fläche auf beiden Lagen.

- **USB:** Der D1 mini schließt mit der USB-Seite bündig an der Unterkante ab. Vor der Buchse ist nichts im Weg.
- **Antenne:** Die Antennen von D1 mini und WROOM ragen oben über den Rand. Darunter ist Kupfer gesperrt.
- **Variante B** (WROOM) liegt zwischen den inneren Buchsenreihen des D1 mini. Deshalb hat der Sockel-Footprint keinen Courtyard.
- Rechte Hälfte:
  - PS/2-Stecker J1, beschriftet mit 5V, G, D, C
  - JP1
  - Pegelwandler
  - Spannungsregler
  - Taster BOOT und RESET
  - J3, Belegung: 1 GND, 2 TX, 3 RX, 4 5V
  - LED
  - zwei M3-Löcher
- Die Bauteilnamen der kleinen SMD-Teile stehen nur auf der Fab-Lage, weil der Platz knapp ist. Zum Löten die Bestückungszeichnung verwenden.

## Version 1 — was drauf ist

| Block | Inhalt |
|---|---|
| 1 Anschluss | J1 ist ein JST-XH-Stecker mit 4 Polen (+5V, GND, DATA, CLK). Daran hängt ein Kabel mit Mini-DIN-6 (PS/2) oder DIN-5. JP1 trennt die 5 V vom PC. |
| 2 Pegelwandler | Zwei BSS138, je 10k Pull-up auf beiden Seiten. Immer bestückt. |
| 3 Variante A | D1 mini ESP32, gesteckt auf Buchsenleisten (4 × 10 Pins). Standardvariante. |
| 4 Variante B | ESP32-WROOM-32E-N4 aufgelötet, dazu Spannungsregler AP2112K-3.3, die Taster BOOT und RESET, eine LED an IO2 und J3 für den USB-Seriell-Adapter. |

Bestückt wird **entweder** Variante A **oder** Variante B. Beide nutzen dieselben Pins wie das Original: IO22 = CLK, IO23 = DATA.

## Beim Betrieb

- **JP1 ziehen**, solange das Board über USB oder J3 versorgt wird. Sonst fließen 5 V zurück in den PC. Davor warnt auch das README des Projekts.
- PS/2 ist nicht hot-plug-fähig. Anstecken nur bei ausgeschaltetem PC.

## Annahmen, die noch niemand bestätigt hat

1. **Pinbelegung des D1 mini ESP32:** bestätigt am Pinout-Bild im eigenen Beitrag „(Wemos) D1 ESP32“ auf fambach.net. Alle vier Reihen stimmen, D1 = IO22 und D7 = IO23.
2. **Umriss und Antenne:** 39 × 32 mm laut demselben Beitrag. Die Lage von Antenne (oben) und USB (unten) habe ich **aus dem Foto geschätzt, auf etwa 1 mm genau**. Unter dem Antennenbereich liegt im Footprint eine Sperrfläche für Kupfer.
   Ein Board im Format des alten D1 mini (34,5 × 25,5 mm, eine Reihe je Seite) passt mechanisch in die inneren Reihen. Es funktioniert aber nur, wenn darauf ein klassischer ESP32 sitzt, also kein C3, S2 oder S3.
3. **Pull-ups auf der 5-V-Seite (R1, R3):** Der PC hat eigene Pull-ups. Unsere liegen parallel dazu. Das ist üblich und schadet nicht, ist hier aber noch nicht erprobt.
4. **Maus (Version 2):** IO25 und IO26 bleiben frei. Einen zweiten Anschluss gibt es noch nicht.

## Dateien

| Datei | |
|---|---|
| `bt2ps2.kicad_pro` / `.kicad_sch` / `.kicad_pcb` / `.kicad_dru` | KiCad-10-Projekt aus der Vorlage `vorlage/jlcpcb-2lagen` |
| `bt2ps2.kicad_sym`, `bt2ps2.pretty/` | Symbol und Footprint für den D1 mini ESP32 |
| `fp-lib-table` | enthält zusätzlich die KiCad-Standardfootprints, weil sie in der globalen Tabelle fehlen |
| `bt2ps2-schaltplan.pdf` | Schaltplan zum Ansehen |
| `bt2ps2-oben.png`, `bt2ps2-unten.png`, `bt2ps2-3d.png` | Ansichten der Platine |
| `werkzeug/` | Die Skripte, mit denen Schaltplan, Platzierung und Verlegung erzeugt wurden (KiCad-Python). **Nur zum Nachvollziehen:** Ein erneuter Lauf überschreibt Handarbeit in KiCad. |

## Fertigung (Stand 2026-09-19)

| Datei in `fertigung/` | wofür |
|---|---|
| `bt2ps2-jlcpcb-gerber.zip` | zum Hochladen bei JLCPCB (Gerber + Bohrdatei) |
| `bestueckung-oben.pdf`, `bestueckung-unten.pdf` | Bestückungszeichnung mit allen Bauteilnamen |
| `bt2ps2-ibom.html` | interaktive Bestückungshilfe im Browser: Bauteil anklicken, es leuchtet auf der Platine auf |
| `stueckliste.csv` | Stückliste |

**Bestellangaben:** 2 Lagen, 61,0 × 34,1 mm, FR4, 1,6 mm, 1 oz, HASL bleifrei, Farbe frei. Alle Werte liegen im Standardbereich. Kleinste Bohrung: 0,2 mm mit 0,6 mm Pad (12 Stück im Massepad des WROOM). Laut JLCPCB kostet das keinen Aufpreis.

**Beim Kauf nicht vergessen:** Für den D1 mini braucht es 4 Buchsenleisten 1 × 10 (Raster 2,54 mm), passend zu den Stiftleisten am Board. Außerdem einen Jumper für JP1 und das Kabel J1 → PS/2 bzw. DIN (JST-XH-Buchse mit 4 Polen und Crimpkontakten).
