# ESP32 Bluetooth → PS/2 Tastatur-Adapter — THT-Variante

Bedrahtete Schwester von [`../esp32-bt2ps2`](../esp32-bt2ps2/README.md): gleiche Schaltung, gleiche Pins (IO22 = CLK, IO23 = DATA), gleicher Anschluss J1 und Jumper JP1. Alles zum Durchstecken — **bis auf das ESP32-WROOM-32E der Variante B, das einzige SMD-Bauteil**.

**Stand 2026-09-19: Schaltplan (ERC ohne Befund), Platine verlegt (DRC ohne Befund, alles verbunden), Fertigungsdaten erzeugt.**

## Unterschiede zur SMD-Variante

| | SMD | THT |
|---|---|---|
| Mikrocontroller | D1 mini ESP32 **oder** WROOM-32E aufgelötet | ebenso — das WROOM ist hier das **einzige SMD-Bauteil** |
| Pegelwandler | BSS138 (SOT-23) | **2N7000 (TO-92)**, Pins im 2,54-mm-Raster |
| Widerstände | 0805 | bedrahtet 0207 (¼ W), Raster 7,62 mm |
| Spannungsregler (nur Variante B) | AP2112K (SOT-23-5) | **LD1117V33 (TO-220)**, dazu 2 × 10 µF Elko |
| Kondensatoren | 0805 | Scheibenkondensatoren (5 mm Raster), Elkos 5 mm |
| LED | 0805 | 3 mm |
| Größe | 61,0 × 34,1 mm | **83,0 × 34,1 mm** |

## Annahme, die erprobt werden muss

**2N7000 an 3,3 V Gate-Spannung:** Die Schaltschwelle Vgs(th) liegt typisch bei 2,1 V, laut Datenblatt aber bis zu 3 V. Bei einem Exemplar am oberen Ende schaltet der Transistor mit 3,3 V nur schwach. Für PS/2 reicht das, weil nur wenig Strom fließt. Trotzdem: **erst auf dem Steckbrett testen.** Falls es hakt, passt der BS170 nicht ohne Weiteres, weil seine Pins anders belegt sind (D-G-S statt S-G-D).

## Fertigung

| Datei in `fertigung/` | wofür |
|---|---|
| `bt2ps2-tht-jlcpcb-gerber.zip` | zum Hochladen bei JLCPCB |
| `bestueckung-oben.pdf`, `bt2ps2-tht-ibom.html` | Bestückungshilfe |
| `stueckliste.csv` | Stückliste |
| `bt2ps2-tht-jlcpcb-positionen.csv` | Positionsdaten (Pick-and-place) für die Bestückung bei JLCPCB |

Bestellangaben wie bei der SMD-Variante, aber 83,0 × 34,1 mm. Kleinste Bohrung 0,2 mm mit 0,6 mm Pad (12 Stück im Massepad des WROOM) — laut JLCPCB ohne Aufpreis.

**Beim Kauf, Variante A (D1 mini):** 4 Buchsenleisten 1 × 10, ein Jumper, die JST-XH-Buchse mit 4 Polen und Crimpkontakten, 2 × 2N7000, 4 × 10 kΩ.
**Variante B (WROOM) statt der Buchsenleisten:** ESP32-WROOM-32E-N4, LD1117V33, 2 × 10 µF Elko, 2 × 100 nF, 1 × 1 µF, 2 × 10 kΩ, 1 × 1 kΩ, LED 3 mm, 2 Taster 6 mm, Stiftleiste 1 × 4. Die vollständige Liste steht in `fertigung/stueckliste.csv`.

**Hinweis:** C5 (100 nF am WROOM) liegt unter dem Platz des D1 mini — er gehört nur zu Variante B.

## Dateien

`werkzeug/` enthält die Skripte, die Schaltplan, Platzierung und Verlegung erzeugt haben. **Nur zum Nachvollziehen:** Ein erneuter Lauf überschreibt Handarbeit in KiCad.

**Positionsdaten:** Der Nullpunkt liegt in der linken unteren Ecke der Platine. Die Datei enthält **alle** Bauteile, auch die bedrahteten; JLCPCB bestückt nur die SMD-Teile. Für einen Bestückungsauftrag fehlen noch die LCSC-Nummern in der Stückliste.
